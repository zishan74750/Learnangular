// This file should be compiled using --noImplicitAny to ensure the .d.ts files are noImplicitAny compliant.
// tsc --noEmit --noImplicitAny --moduleResolution node --target es6 test/noimplicitany.ts

import * as router from  "../lib/index";
console.log(router);
